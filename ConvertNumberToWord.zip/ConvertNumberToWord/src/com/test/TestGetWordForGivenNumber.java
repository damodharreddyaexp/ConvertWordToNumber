package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.damodhar.NumberToWord;

public class TestGetWordForGivenNumber {
	NumberToWord numberToWord = new NumberToWord();

	@Test
	public void testGetWordForGivenNumber() {

		NumberToWord numberToWord = new NumberToWord();
		assertEquals(numberToWord.getWordForGivenNumber(105), "one hundred and five");

	}

	@Test
	public void testNumberToWord() {

		assertEquals(numberToWord.numberToWord(121), "one hundred and twenty one");

	}
}
