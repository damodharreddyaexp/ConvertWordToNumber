package com.damodhar;

/**
 * Class to print the British English word of given number.
 * 
 * @author damodhar
 *
 */
public class NumberToWord extends WordForZeroToHundred {

	/**
	 * Method to print the english word.
	 * 
	 * @param number
	 */
	public String numberToWord(Integer number) {
		String numToWord = "";
		if (number != null && number <= 999999999) {
			numToWord = getWord(number);

			System.out.println(number + " = " + numToWord);
		} else {
			System.out.println("Please enter valid input is 0 to 999999999");
		}
		return numToWord;
	}

	/**
	 * Method to return the word in hundreds from 0 to 999999999.
	 * 
	 * @param number
	 * @return String
	 */
	private String getWord(Integer number) {
		StringBuilder word = new StringBuilder();
		if (number != 0 && number <= 999999999) {
			if (number > 0 && number < 1000) {
				word.append(getWordForGivenNumber(number));
			} else if (number > 999 && number < 1000000) {

				word.append(getWordForGivenNumber(number / 1000)).append(" thousand ")
						.append(getWordForGivenNumber(number % 1000));
			} else if (number > 999999) {
				Integer thousandWord = number / 1000;
				word.append(getWordForGivenNumber(thousandWord / 1000)).append(" million ")
						.append(getWordForGivenNumber(thousandWord % 1000)).append(" thousand ")
						.append(getWordForGivenNumber(number % 1000));
			}
		} else {
			System.out.println("invalid input in getWordHunderd.");
		}
		return word.toString();
	}
}
