package com.damodhar;

import java.util.Scanner;

public class NumberToWordMain {
	public static void main(String[] args) {
		try {
			Scanner myObj = new Scanner(System.in);
			System.out.println("Enter input:: ");
			String input = myObj.nextLine();
			if (input != null && input.length() > 0) {
				Integer number = Integer.parseInt(input);
				NumberToWord numberToWord = new NumberToWord();
				String numToWord = numberToWord.numberToWord(number);
				System.out.println("NumTo Word ::" + numToWord); 
			} else {
				System.out.println("No input provided for given number");
			}
		} catch (NumberFormatException e) {
			System.out.println("Invalid input.");
		}
	}
}
