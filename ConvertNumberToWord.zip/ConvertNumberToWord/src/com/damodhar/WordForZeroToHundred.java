package com.damodhar;
import java.util.HashMap;
import java.util.Map;

/**
 * Class to return the word from Zero To Hunderd
 * 
 * @author damodhar
 *
 */
public class WordForZeroToHundred {

	static Map<Integer, String> tens = new HashMap<>();
	static Map<Integer, String> ones = new HashMap<>();

	static {
		tens.put(1, "ten");
		tens.put(2, "twenty");
		tens.put(3, "thirty");
		tens.put(4, "forty");
		tens.put(5, "fifty");
		tens.put(6, "sixty");
		tens.put(7, "seventy");
		tens.put(8, "eighty");
		tens.put(9, "ninty");

		ones.put(1, "one");
		ones.put(2, "two");
		ones.put(3, "three");
		ones.put(4, "four");
		ones.put(5, "five");
		ones.put(6, "six");
		ones.put(7, "seven");
		ones.put(8, "eight");
		ones.put(9, "nine");
	}

	/**
	 * Method to give word in zero to 999 number.
	 * 
	 * @param number
	 * @return String
	 */
	public String getWordForGivenNumber(Integer number) {
		String word = null;
		if (number > 0 && number < 10) {
			word = ones.get(number);
		} else if (number > 9 && number < 100) {
			word = getTensWord(number);
		} else if (number > 99) {
			word = getHunderdWord(number);
		}
		// System.out.println(word);
		return word;
	}

	/**
	 * Method to return word from zero to nine hundred and ninety nine.
	 * 
	 * @param number
	 * @return String
	 */
	private static String getHunderdWord(Integer number) {
		StringBuilder st = new StringBuilder();
		if (number > 99 && number < 1000) {
			Integer numberInHunderd = number / 100;
			st.append(ones.get(numberInHunderd)).append(" hundred");
			String tensWord = getTensWord(number % 100);
			if (tensWord != null && !tensWord.trim().equals("")) {
				st.append(" and ").append(tensWord);
			} else {
				number = number % 10;
				if (number > 0) {
					st.append(" and ").append(ones.get(number));
				}
			}
		}
		// System.out.println("hundreds: "+ st.toString());
		return st.toString();
	}

	/**
	 * Method to return words from ten to ninety nine
	 * 
	 * @param number
	 * @return String
	 */
	private static String getTensWord(Integer number) {
		StringBuilder st = new StringBuilder();
		if (number > 9 && number < 100) {
			Integer numberInTen = number / 10;
			st.append(tens.get(numberInTen)).append(" ");
			if (ones.get(number % 10) != null) {
				st.append(ones.get(number % 10));
			}
		}
		// System.out.println("tens: "+ st.toString());
		return st.toString();
	}
}
